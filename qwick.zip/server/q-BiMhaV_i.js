import{j as d,b as le,c as me,F as z,s as X,d as H,i as V,u as ue,e as de,f as g,g as y,h as pe,k as w,l as J,S as fe,R as _e,Q as ye}from"./q-Dnkd9PZT.js";/**
 * @license
 * @builder.io/qwik/server 1.4.5
 * Copyright Builder.io, Inc. All Rights Reserved.
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/BuilderIO/qwik/blob/main/LICENSE
 */var he=(e=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(e,{get:(n,t)=>(typeof require<"u"?require:n)[t]}):e)(function(e){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+e+'" is not supported')}),qe="<sync>";function Z(e,n){const t=n==null?void 0:n.mapper,s=e.symbolMapper?e.symbolMapper:i=>{var a;if(t){const o=C(i),c=t[o];if(!c){if(o===qe)return[o,""];if((a=globalThis.__qwik_reg_symbols)==null?void 0:a.has(o))return[i,"_"];console.error("Cannot resolve symbol",i,"in",t)}return c}};return{isServer:!0,async importSymbol(i,a,o){var b;const c=C(o),l=(b=globalThis.__qwik_reg_symbols)==null?void 0:b.get(c);if(l)return l;let u=String(a);u.endsWith(".js")||(u+=".js");const v=he(u);if(!(o in v))throw new Error(`Q-ERROR: missing symbol '${o}' in module '${u}'.`);return v[o]},raf:()=>(console.error("server can not rerender"),Promise.resolve()),nextTick:i=>new Promise(a=>{setTimeout(()=>{a(i())})}),chunkForSymbol(i){return s(i,t)}}}async function ge(e,n){const t=Z(e,n);X(t)}var C=e=>{const n=e.lastIndexOf("_");return n>-1?e.slice(n+1):e};function k(){if(typeof performance>"u")return()=>0;const e=performance.now();return()=>(performance.now()-e)/1e6}function G(e){let n=e.base;return typeof e.base=="function"&&(n=e.base(e)),typeof n=="string"?(n.endsWith("/")||(n+="/"),n):"/build/"}var be=`((e,t)=>{const n="__q_context__",s=window,o=new Set,i=t=>e.querySelectorAll(t),a=(e,t,n=t.type)=>{i("[on"+e+"\\\\:"+n+"]").forEach((s=>f(s,e,t,n)))},r=(e,t)=>e.getAttribute(t),l=t=>{if(void 0===t._qwikjson_){let n=(t===e.documentElement?e.body:t).lastElementChild;for(;n;){if("SCRIPT"===n.tagName&&"qwik/json"===r(n,"type")){t._qwikjson_=JSON.parse(n.textContent.replace(/\\\\x3C(\\/?script)/gi,"<$1"));break}n=n.previousElementSibling}}},c=(e,t)=>new CustomEvent(e,{detail:t}),f=async(t,s,o,i=o.type)=>{const a="on"+s+":"+i;t.hasAttribute("preventdefault:"+i)&&o.preventDefault();const c=t._qc_,f=null==c?void 0:c.li.filter((e=>e[0]===a));if(f&&f.length>0){for(const e of f)await e[1].getFn([t,o],(()=>t.isConnected))(o,t);return}const b=r(t,a);if(b){const s=t.closest("[q\\\\:container]"),i=new URL(r(s,"q:base"),e.baseURI);for(const a of b.split("\\n")){const r=new URL(a,i),c=r.hash.replace(/^#?([^?[|]*).*$/,"$1")||"default",f=performance.now();let b;const d=a.startsWith("#");if(d)b=(s.qFuncs||[])[Number.parseInt(c)];else{const e=import(
/* @vite-ignore */
r.href.split("#")[0]);l(s),b=(await e)[c]}const p=e[n];if(t.isConnected)try{e[n]=[t,o,r],d||u("qsymbol",{symbol:c,element:t,reqTime:f}),await b(o,t)}finally{e[n]=p}}}},u=(t,n)=>{e.dispatchEvent(c(t,n))},b=e=>e.replace(/([A-Z])/g,(e=>"-"+e.toLowerCase())),d=async e=>{let t=b(e.type),n=e.target;for(a("-document",e,t);n&&n.getAttribute;)await f(n,"",e,t),n=e.bubbles&&!0!==e.cancelBubble?n.parentElement:null},p=e=>{a("-window",e,b(e.type))},q=()=>{var n;const a=e.readyState;if(!t&&("interactive"==a||"complete"==a)&&(t=1,u("qinit"),(null!=(n=s.requestIdleCallback)?n:s.setTimeout).bind(s)((()=>u("qidle"))),o.has("qvisible"))){const e=i("[on\\\\:qvisible]"),t=new IntersectionObserver((e=>{for(const n of e)n.isIntersecting&&(t.unobserve(n.target),f(n.target,"",c("qvisible",n)))}));e.forEach((e=>t.observe(e)))}},w=(e,t,n,s=!1)=>e.addEventListener(t,n,{capture:s,passive:!1}),v=t=>{for(const n of t)o.has(n)||(w(e,n,d,!0),w(s,n,p),o.add(n))};if(!e.qR){const t=s.qwikevents;Array.isArray(t)&&v(t),s.qwikevents={push:(...e)=>v(e)},w(e,"readystatechange",q),q()}})(document);`,ve=`(() => {
    ((doc, hasInitialized) => {
        const win = window;
        const events =  new Set;
        const querySelectorAll = query => doc.querySelectorAll(query);
        const broadcast = (infix, ev, type = ev.type) => {
            querySelectorAll("[on" + infix + "\\\\:" + type + "]").forEach((target => dispatch(target, infix, ev, type)));
        };
        const getAttribute = (el, name) => el.getAttribute(name);
        const resolveContainer = containerEl => {
            if (void 0 === containerEl._qwikjson_) {
                let script = (containerEl === doc.documentElement ? doc.body : containerEl).lastElementChild;
                while (script) {
                    if ("SCRIPT" === script.tagName && "qwik/json" === getAttribute(script, "type")) {
                        containerEl._qwikjson_ = JSON.parse(script.textContent.replace(/\\\\x3C(\\/?script)/gi, "<$1"));
                        break;
                    }
                    script = script.previousElementSibling;
                }
            }
        };
        const createEvent = (eventName, detail) => new CustomEvent(eventName, {
            detail: detail
        });
        const dispatch = async (element, onPrefix, ev, eventName = ev.type) => {
            const attrName = "on" + onPrefix + ":" + eventName;
            element.hasAttribute("preventdefault:" + eventName) && ev.preventDefault();
            const ctx = element._qc_;
            const relevantListeners = null == ctx ? void 0 : ctx.li.filter((li => li[0] === attrName));
            if (relevantListeners && relevantListeners.length > 0) {
                for (const listener of relevantListeners) {
                    await listener[1].getFn([ element, ev ], (() => element.isConnected))(ev, element);
                }
                return;
            }
            const attrValue = getAttribute(element, attrName);
            if (attrValue) {
                const container = element.closest("[q\\\\:container]");
                const base = new URL(getAttribute(container, "q:base"), doc.baseURI);
                for (const qrl of attrValue.split("\\n")) {
                    const url = new URL(qrl, base);
                    const symbolName = url.hash.replace(/^#?([^?[|]*).*$/, "$1") || "default";
                    const reqTime = performance.now();
                    let handler;
                    const isSync = qrl.startsWith("#");
                    if (isSync) {
                        handler = (container.qFuncs || [])[Number.parseInt(symbolName)];
                    } else {
                        const module = import(
                        /* @vite-ignore */
                        url.href.split("#")[0]);
                        resolveContainer(container);
                        handler = (await module)[symbolName];
                    }
                    const previousCtx = doc.__q_context__;
                    if (element.isConnected) {
                        try {
                            doc.__q_context__ = [ element, ev, url ];
                            isSync || emitEvent("qsymbol", {
                                symbol: symbolName,
                                element: element,
                                reqTime: reqTime
                            });
                            await handler(ev, element);
                        } finally {
                            doc.__q_context__ = previousCtx;
                        }
                    }
                }
            }
        };
        const emitEvent = (eventName, detail) => {
            doc.dispatchEvent(createEvent(eventName, detail));
        };
        const camelToKebab = str => str.replace(/([A-Z])/g, (a => "-" + a.toLowerCase()));
        const processDocumentEvent = async ev => {
            let type = camelToKebab(ev.type);
            let element = ev.target;
            broadcast("-document", ev, type);
            while (element && element.getAttribute) {
                await dispatch(element, "", ev, type);
                element = ev.bubbles && !0 !== ev.cancelBubble ? element.parentElement : null;
            }
        };
        const processWindowEvent = ev => {
            broadcast("-window", ev, camelToKebab(ev.type));
        };
        const processReadyStateChange = () => {
            var _a;
            const readyState = doc.readyState;
            if (!hasInitialized && ("interactive" == readyState || "complete" == readyState)) {
                hasInitialized = 1;
                emitEvent("qinit");
                (null != (_a = win.requestIdleCallback) ? _a : win.setTimeout).bind(win)((() => emitEvent("qidle")));
                if (events.has("qvisible")) {
                    const results = querySelectorAll("[on\\\\:qvisible]");
                    const observer = new IntersectionObserver((entries => {
                        for (const entry of entries) {
                            if (entry.isIntersecting) {
                                observer.unobserve(entry.target);
                                dispatch(entry.target, "", createEvent("qvisible", entry));
                            }
                        }
                    }));
                    results.forEach((el => observer.observe(el)));
                }
            }
        };
        const addEventListener = (el, eventName, handler, capture = !1) => el.addEventListener(eventName, handler, {
            capture: capture,
            passive: !1
        });
        const push = eventNames => {
            for (const eventName of eventNames) {
                if (!events.has(eventName)) {
                    addEventListener(doc, eventName, processDocumentEvent, !0);
                    addEventListener(win, eventName, processWindowEvent);
                    events.add(eventName);
                }
            }
        };
        if (!doc.qR) {
            const qwikevents = win.qwikevents;
            Array.isArray(qwikevents) && push(qwikevents);
            win.qwikevents = {
                push: (...e) => push(e)
            };
            addEventListener(doc, "readystatechange", processReadyStateChange);
            processReadyStateChange();
        }
    })(document);
})();`,we=`((e,t)=>{const n="__q_context__",s=window,o=new Set,i=t=>e.querySelectorAll(t),a=(e,t,n=t.type)=>{i("[on"+e+"\\\\:"+n+"]").forEach((s=>f(s,e,t,n)))},r=(e,t)=>e.getAttribute(t),l=t=>{if(void 0===t._qwikjson_){let n=(t===e.documentElement?e.body:t).lastElementChild;for(;n;){if("SCRIPT"===n.tagName&&"qwik/json"===r(n,"type")){t._qwikjson_=JSON.parse(n.textContent.replace(/\\\\x3C(\\/?script)/gi,"<$1"));break}n=n.previousElementSibling}}},c=(e,t)=>new CustomEvent(e,{detail:t}),f=async(t,s,o,i=o.type)=>{const a="on"+s+":"+i;t.hasAttribute("preventdefault:"+i)&&o.preventDefault();const c=t._qc_,f=null==c?void 0:c.li.filter((e=>e[0]===a));if(f&&f.length>0){for(const e of f)await e[1].getFn([t,o],(()=>t.isConnected))(o,t);return}const b=r(t,a);if(b){const s=t.closest("[q\\\\:container]"),i=new URL(r(s,"q:base"),e.baseURI);for(const a of b.split("\\n")){const r=new URL(a,i),c=r.hash.replace(/^#?([^?[|]*).*$/,"$1")||"default",f=performance.now();let b;const d=a.startsWith("#");if(d)b=(s.qFuncs||[])[Number.parseInt(c)];else{const e=import(
/* @vite-ignore */
r.href.split("#")[0]);l(s),b=(await e)[c]}const p=e[n];if(t.isConnected)try{e[n]=[t,o,r],d||u("qsymbol",{symbol:c,element:t,reqTime:f}),await b(o,t)}finally{e[n]=p}}}},u=(t,n)=>{e.dispatchEvent(c(t,n))},b=e=>e.replace(/([A-Z])/g,(e=>"-"+e.toLowerCase())),d=async e=>{let t=b(e.type),n=e.target;for(a("-document",e,t);n&&n.getAttribute;)await f(n,"",e,t),n=e.bubbles&&!0!==e.cancelBubble?n.parentElement:null},p=e=>{a("-window",e,b(e.type))},q=()=>{var n;const a=e.readyState;if(!t&&("interactive"==a||"complete"==a)&&(t=1,u("qinit"),(null!=(n=s.requestIdleCallback)?n:s.setTimeout).bind(s)((()=>u("qidle"))),o.has("qvisible"))){const e=i("[on\\\\:qvisible]"),t=new IntersectionObserver((e=>{for(const n of e)n.isIntersecting&&(t.unobserve(n.target),f(n.target,"",c("qvisible",n)))}));e.forEach((e=>t.observe(e)))}},w=(e,t,n,s=!1)=>e.addEventListener(t,n,{capture:s,passive:!1}),v=t=>{for(const n of t)o.has(n)||(w(e,n,d,!0),w(s,n,p),o.add(n))};if(!e.qR){const t=s.qwikevents;Array.isArray(t)&&v(t),s.qwikevents={push:(...e)=>v(e)},w(e,"readystatechange",q),q()}})(document);`,xe=`(() => {
    ((doc, hasInitialized) => {
        const win = window;
        const events = new Set;
        const querySelectorAll = query => doc.querySelectorAll(query);
        const broadcast = (infix, ev, type = ev.type) => {
            querySelectorAll("[on" + infix + "\\\\:" + type + "]").forEach((target => dispatch(target, infix, ev, type)));
        };
        const getAttribute = (el, name) => el.getAttribute(name);
        const resolveContainer = containerEl => {
            if (void 0 === containerEl._qwikjson_) {
                let script = (containerEl === doc.documentElement ? doc.body : containerEl).lastElementChild;
                while (script) {
                    if ("SCRIPT" === script.tagName && "qwik/json" === getAttribute(script, "type")) {
                        containerEl._qwikjson_ = JSON.parse(script.textContent.replace(/\\\\x3C(\\/?script)/gi, "<$1"));
                        break;
                    }
                    script = script.previousElementSibling;
                }
            }
        };
        const createEvent = (eventName, detail) => new CustomEvent(eventName, {
            detail: detail
        });
        const dispatch = async (element, onPrefix, ev, eventName = ev.type) => {
            const attrName = "on" + onPrefix + ":" + eventName;
            element.hasAttribute("preventdefault:" + eventName) && ev.preventDefault();
            const ctx = element._qc_;
            const relevantListeners = null == ctx ? void 0 : ctx.li.filter((li => li[0] === attrName));
            if (relevantListeners && relevantListeners.length > 0) {
                for (const listener of relevantListeners) {
                    await listener[1].getFn([ element, ev ], (() => element.isConnected))(ev, element);
                }
                return;
            }
            const attrValue = getAttribute(element, attrName);
            if (attrValue) {
                const container = element.closest("[q\\\\:container]");
                const base = new URL(getAttribute(container, "q:base"), doc.baseURI);
                for (const qrl of attrValue.split("\\n")) {
                    const url = new URL(qrl, base);
                    const symbolName = url.hash.replace(/^#?([^?[|]*).*$/, "$1") || "default";
                    const reqTime = performance.now();
                    let handler;
                    const isSync = qrl.startsWith("#");
                    if (isSync) {
                        handler = (container.qFuncs || [])[Number.parseInt(symbolName)];
                    } else {
                        const module = import(
                        /* @vite-ignore */
                        url.href.split("#")[0]);
                        resolveContainer(container);
                        handler = (await module)[symbolName];
                    }
                    const previousCtx = doc.__q_context__;
                    if (element.isConnected) {
                        try {
                            doc.__q_context__ = [ element, ev, url ];
                            isSync || emitEvent("qsymbol", {
                                symbol: symbolName,
                                element: element,
                                reqTime: reqTime
                            });
                            await handler(ev, element);
                        } finally {
                            doc.__q_context__ = previousCtx;
                        }
                    }
                }
            }
        };
        const emitEvent = (eventName, detail) => {
            doc.dispatchEvent(createEvent(eventName, detail));
        };
        const camelToKebab = str => str.replace(/([A-Z])/g, (a => "-" + a.toLowerCase()));
        const processDocumentEvent = async ev => {
            let type = camelToKebab(ev.type);
            let element = ev.target;
            broadcast("-document", ev, type);
            while (element && element.getAttribute) {
                await dispatch(element, "", ev, type);
                element = ev.bubbles && !0 !== ev.cancelBubble ? element.parentElement : null;
            }
        };
        const processWindowEvent = ev => {
            broadcast("-window", ev, camelToKebab(ev.type));
        };
        const processReadyStateChange = () => {
            var _a;
            const readyState = doc.readyState;
            if (!hasInitialized && ("interactive" == readyState || "complete" == readyState)) {
                hasInitialized = 1;
                emitEvent("qinit");
                (null != (_a = win.requestIdleCallback) ? _a : win.setTimeout).bind(win)((() => emitEvent("qidle")));
                if (events.has("qvisible")) {
                    const results = querySelectorAll("[on\\\\:qvisible]");
                    const observer = new IntersectionObserver((entries => {
                        for (const entry of entries) {
                            if (entry.isIntersecting) {
                                observer.unobserve(entry.target);
                                dispatch(entry.target, "", createEvent("qvisible", entry));
                            }
                        }
                    }));
                    results.forEach((el => observer.observe(el)));
                }
            }
        };
        const addEventListener = (el, eventName, handler, capture = !1) => el.addEventListener(eventName, handler, {
            capture: capture,
            passive: !1
        });
        const push = eventNames => {
            for (const eventName of eventNames) {
                if (!events.has(eventName)) {
                    addEventListener(doc, eventName, processDocumentEvent, !0);
                    addEventListener(win, eventName, processWindowEvent);
                    events.add(eventName);
                }
            }
        };
        if (!doc.qR) {
            const qwikevents = win.qwikevents;
            Array.isArray(qwikevents) && push(qwikevents);
            win.qwikevents = {
                push: (...e) => push(e)
            };
            addEventListener(doc, "readystatechange", processReadyStateChange);
            processReadyStateChange();
        }
    })(document);
})();`;function je(e={}){return Array.isArray(e.events)&&e.events.length>0?(e.debug?xe:we).replace("window.qEvents",JSON.stringify(e.events)):e.debug?ve:be}function ke(e,n,t){if(!t)return[];const s=n.prefetchStrategy,r=G(n);if(s!==null){if(!s||!s.symbolsToPrefetch||s.symbolsToPrefetch==="auto")return Ce(e,t,r);if(typeof s.symbolsToPrefetch=="function")try{return s.symbolsToPrefetch({manifest:t.manifest})}catch(i){console.error("getPrefetchUrls, symbolsToPrefetch()",i)}}return[]}function Ce(e,n,t){const s=[],r=e==null?void 0:e.qrls,{mapper:i,manifest:a}=n,o=new Map;if(Array.isArray(r))for(const c of r){const l=c.getHash(),u=i[l];u&&ee(a,o,s,t,u[1])}return s}function ee(e,n,t,s,r){const i=s+r;let a=n.get(i);if(!a){a={url:i,imports:[]},n.set(i,a);const o=e.bundles[r];if(o&&Array.isArray(o.imports))for(const c of o.imports)ee(e,n,a.imports,s,c)}t.push(a)}function Ne(e){if(e!=null&&e.mapping!=null&&typeof e.mapping=="object"&&e.symbols!=null&&typeof e.symbols=="object"&&e.bundles!=null&&typeof e.bundles=="object")return e}function N(){let r=`const w=new Worker(URL.createObjectURL(new Blob(['onmessage=(e)=>{Promise.all(e.data.map(u=>fetch(u))).finally(()=>{setTimeout(postMessage({}),9999)})}'],{type:"text/javascript"})));`;return r+="w.postMessage(u.map(u=>new URL(u,origin)+''));",r+="w.onmessage=()=>{w.terminate()};",r}function ze(e){const n={bundles:x(e).map(t=>t.split("/").pop())};return`document.dispatchEvent(new CustomEvent("qprefetch",{detail:${JSON.stringify(n)}}))`}function x(e){const n=[],t=s=>{if(Array.isArray(s))for(const r of s)n.includes(r.url)||(n.push(r.url),t(r.imports))};return t(e),n}function Ee(e){const n=new Map;let t=0;const s=(o,c)=>{if(Array.isArray(o))for(const l of o){const u=n.get(l.url)||0;n.set(l.url,u+1),t++,c.has(l.url)||(c.add(l.url),s(l.imports,c))}},r=new Set;for(const o of e)r.clear(),s(o.imports,r);const i=t/n.size*2,a=Array.from(n.entries());return a.sort((o,c)=>c[1]-o[1]),a.slice(0,5).filter(o=>o[1]>i).map(o=>o[0])}function Se(e,n,t){const s=Qe(e==null?void 0:e.implementation),r=[];return s.prefetchEvent==="always"&&Ie(r,n,t),s.linkInsert==="html-append"&&De(r,n,s),s.linkInsert==="js-append"?Ae(r,n,s,t):s.workerFetchInsert==="always"&&Le(r,n,t),r.length>0?d(z,{children:r}):null}function Ie(e,n,t){const s=Ee(n);for(const r of s)e.push(d("link",{rel:"modulepreload",href:r,nonce:t}));e.push(d("script",{"q:type":"prefetch-bundles",dangerouslySetInnerHTML:ze(n)+";document.dispatchEvent(new CustomEvent('qprefetch', {detail:{links: [location.pathname]}}))",nonce:t}))}function De(e,n,t){const s=x(n),r=t.linkRel||"prefetch";for(const i of s){const a={};a.href=i,a.rel=r,(r==="prefetch"||r==="preload")&&i.endsWith(".js")&&(a.as="script"),e.push(d("link",a,void 0))}}function Ae(e,n,t,s){const r=t.linkRel||"prefetch";let i="";t.workerFetchInsert==="no-link-support"&&(i+="let supportsLinkRel = true;"),i+=`const u=${JSON.stringify(x(n))};`,i+="u.map((u,i)=>{",i+="const l=document.createElement('link');",i+='l.setAttribute("href",u);',i+=`l.setAttribute("rel","${r}");`,t.workerFetchInsert==="no-link-support"&&(i+="if(i===0){",i+="try{",i+=`supportsLinkRel=l.relList.supports("${r}");`,i+="}catch(e){}",i+="}"),i+="document.body.appendChild(l);",i+="});",t.workerFetchInsert==="no-link-support"&&(i+="if(!supportsLinkRel){",i+=N(),i+="}"),t.workerFetchInsert==="always"&&(i+=N()),e.push(d("script",{type:"module","q:type":"link-js",dangerouslySetInnerHTML:i,nonce:s}))}function Le(e,n,t){let s=`const u=${JSON.stringify(x(n))};`;s+=N(),e.push(d("script",{type:"module","q:type":"prefetch-worker",dangerouslySetInnerHTML:s,nonce:t}))}function Qe(e){return{...Fe,...e}}var Fe={linkInsert:null,linkRel:null,workerFetchInsert:null,prefetchEvent:"always"},Pe="<!DOCTYPE html>";async function Ue(e,n){var Q;let t=n.stream,s=0,r=0,i=0,a=0,o="",c;const l=((Q=n.streaming)==null?void 0:Q.inOrder)??{strategy:"auto",maximunInitialChunk:5e4,maximunChunk:3e4},u=n.containerTagName??"html",v=n.containerAttributes??{},b=t,te=k(),se=G(n),p=ne(n.manifest);function E(){o&&(b.write(o),o="",s=0,i++,i===1&&(a=te()))}function S(m){const f=m.length;s+=f,r+=f,o+=m}switch(l.strategy){case"disabled":t={write:S};break;case"direct":t=b;break;case"auto":let m=0,f=!1;const F=l.maximunChunk??0,j=l.maximunInitialChunk??0;t={write(q){q==="<!--qkssr-f-->"?f||(f=!0):q==="<!--qkssr-pu-->"?m++:q==="<!--qkssr-po-->"?m--:S(q),m===0&&(f||s>=(i===0?j:F))&&(f=!1,E())}};break}u==="html"?t.write(Pe):(t.write("<!--cq-->"),n.qwikLoader?(n.qwikLoader.include===void 0&&(n.qwikLoader.include="never"),n.qwikLoader.position===void 0&&(n.qwikLoader.position="bottom")):n.qwikLoader={include:"never"},n.qwikPrefetchServiceWorker||(n.qwikPrefetchServiceWorker={}),n.qwikPrefetchServiceWorker.include||(n.qwikPrefetchServiceWorker.include=!1),n.qwikPrefetchServiceWorker.position||(n.qwikPrefetchServiceWorker.position="top")),n.manifest||console.warn("Missing client manifest, loading symbols in the client might 404. Please ensure the client build has run and generated the manifest for the server build."),await ge(n,p);const I=p==null?void 0:p.manifest.injections,ie=I?I.map(m=>d(m.tag,m.attributes??{})):void 0,re=k(),D=[];let A=0,L=0;await le(e,{stream:t,containerTagName:u,containerAttributes:v,serverData:n.serverData,base:se,beforeContent:ie,beforeClose:async(m,f,F,j)=>{var R,W,Y,M,O,B,K;A=re();const q=k();c=await me(m,f,void 0,j);const h=[];if(n.prefetchStrategy!==null){const _=ke(c,n,p);if(_.length>0){const $=Se(n.prefetchStrategy,_,(R=n.serverData)==null?void 0:R.nonce);$&&h.push($)}}const ae=JSON.stringify(c.state,void 0,void 0);h.push(d("script",{type:"qwik/json",dangerouslySetInnerHTML:Te(ae),nonce:(W=n.serverData)==null?void 0:W.nonce})),c.funcs.length>0&&h.push(d("script",{"q:func":"qwik/json",dangerouslySetInnerHTML:Ye(c.funcs),nonce:(Y=n.serverData)==null?void 0:Y.nonce}));const ce=!c||c.mode!=="static",P=((M=n.qwikLoader)==null?void 0:M.include)??"auto",U=P==="always"||P==="auto"&&ce;if(U){const _=je({events:(O=n.qwikLoader)==null?void 0:O.events,debug:n.debug});h.push(d("script",{id:"qwikloader",dangerouslySetInnerHTML:_,nonce:(B=n.serverData)==null?void 0:B.nonce}))}const T=Array.from(f.$events$,_=>JSON.stringify(_));if(T.length>0){let _=`window.qwikevents.push(${T.join(", ")})`;U||(_=`window.qwikevents||=[];${_}`),h.push(d("script",{dangerouslySetInnerHTML:_,nonce:(K=n.serverData)==null?void 0:K.nonce}))}return Re(D,m),L=q(),d(z,{children:h})},manifestHash:(p==null?void 0:p.manifest.manifestHash)||"dev"}),u!=="html"&&t.write("<!--/cq-->"),E();const oe=c.resources.some(m=>m._cache!==1/0);return{prefetchResources:void 0,snapshotResult:c,flushes:i,manifest:p==null?void 0:p.manifest,size:r,isStatic:!oe,timing:{render:A,snapshot:L,firstFlush:a},_symbols:D}}function ne(e){if(e){if("mapper"in e)return e;if(e=Ne(e),e){const n={};return Object.entries(e.mapping).forEach(([t,s])=>{n[C(t)]=[t,s]}),{mapper:n,manifest:e}}}}var Te=e=>e.replace(/<(\/?script)/gi,"\\x3C$1");function Re(e,n){var t;for(const s of n){const r=(t=s.$componentQrl$)==null?void 0:t.getSymbol();r&&!e.includes(r)&&e.push(r)}}var We='document.currentScript.closest("[q\\\\:container]").qFuncs=';function Ye(e){return We+`[${e.join(`,
`)}]`}async function He(e){const n=Z({manifest:e},ne(e));X(n)}const Me={manifestHash:"xf46py",symbols:{s_02wMImzEAbk:{origin:"../node_modules/@builder.io/qwik-city/index.qwik.mjs",displayName:"QwikCityProvider_component_useTask",canonicalFilename:"s_02wmimzeabk",hash:"02wMImzEAbk",ctxKind:"function",ctxName:"useTask$",captures:!0,parent:"s_TxCFOy819ag",loc:[27091,36262]},s_LQPhZ0qOjrk:{origin:"routes/demo/flower/index.tsx",displayName:"flower_component_useVisibleTask",canonicalFilename:"s_lqphz0qojrk",hash:"LQPhZ0qOjrk",ctxKind:"function",ctxName:"useVisibleTask$",captures:!0,parent:"s_PxZ05oEiFy8",loc:[446,678]},s_3sccYCDd1Z0:{origin:"root.tsx",displayName:"root_component",canonicalFilename:"s_3sccycdd1z0",hash:"3sccYCDd1Z0",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[268,793]},s_5Go3iiHXUB4:{origin:"components/starter/counter/counter.tsx",displayName:"counter_component",canonicalFilename:"s_5go3iihxub4",hash:"5Go3iiHXUB4",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[162,732]},s_7gzriUtQs98:{origin:"components/starter/gauge/index.tsx",displayName:"gauge_component",canonicalFilename:"s_7gzriutqs98",hash:"7gzriUtQs98",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[116,1127]},s_8gdLBszqbaM:{origin:"../node_modules/@builder.io/qwik-city/index.qwik.mjs",displayName:"Link_component",canonicalFilename:"s_8gdlbszqbam",hash:"8gdLBszqbaM",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[38246,40918]},s_J4V2qsF7Yxo:{origin:"routes/demo/todolist/index.tsx",displayName:"todolist_component",canonicalFilename:"s_j4v2qsf7yxo",hash:"J4V2qsF7Yxo",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[565,1631]},s_Nk9PlpjQm9Y:{origin:"../node_modules/@builder.io/qwik-city/index.qwik.mjs",displayName:"GetForm_component",canonicalFilename:"s_nk9plpjqm9y",hash:"Nk9PlpjQm9Y",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[51079,52430]},s_PxZ05oEiFy8:{origin:"routes/demo/flower/index.tsx",displayName:"flower_component",canonicalFilename:"s_pxz05oeify8",hash:"PxZ05oEiFy8",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[243,1575]},s_TxCFOy819ag:{origin:"../node_modules/@builder.io/qwik-city/index.qwik.mjs",displayName:"QwikCityProvider_component",canonicalFilename:"s_txcfoy819ag",hash:"TxCFOy819ag",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[23821,36549]},s_VkLNXphUh5s:{origin:"routes/layout.tsx",displayName:"layout_component",canonicalFilename:"s_vklnxphuh5s",hash:"VkLNXphUh5s",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[928,1068]},s_WmYC5H00wtI:{origin:"../node_modules/@builder.io/qwik-city/index.qwik.mjs",displayName:"QwikCityMockProvider_component",canonicalFilename:"s_wmyc5h00wti",hash:"WmYC5H00wtI",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[36833,38127]},s_e0ssiDXoeAM:{origin:"../node_modules/@builder.io/qwik-city/index.qwik.mjs",displayName:"RouterOutlet_component",canonicalFilename:"s_e0ssidxoeam",hash:"e0ssiDXoeAM",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[7931,8645]},s_fle1EaVOup8:{origin:"components/starter/hero/hero.tsx",displayName:"hero_component",canonicalFilename:"s_fle1eavoup8",hash:"fle1EaVOup8",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[172,2475]},s_foRSjkQluCc:{origin:"components/starter/infobox/infobox.tsx",displayName:"infobox_component",canonicalFilename:"s_forsjkqlucc",hash:"foRSjkQluCc",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[124,261]},s_kJCtKbc9zbk:{origin:"components/starter/next-steps/next-steps.tsx",displayName:"next_steps_component",canonicalFilename:"s_kjctkbc9zbk",hash:"kJCtKbc9zbk",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[1813,3061]},s_mBt9fIl89mc:{origin:"components/starter/header/header.tsx",displayName:"header_component",canonicalFilename:"s_mbt9fil89mc",hash:"mBt9fIl89mc",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[159,1082]},s_u0bwM0i5dA8:{origin:"components/starter/footer/footer.tsx",displayName:"footer_component",canonicalFilename:"s_u0bwm0i5da8",hash:"u0bwM0i5dA8",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[179,558]},s_xYL1qOwPyDI:{origin:"routes/index.tsx",displayName:"routes_component",canonicalFilename:"s_xyl1qowpydi",hash:"xYL1qOwPyDI",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[376,3054]},s_zrbrqoaqXSY:{origin:"components/router-head/router-head.tsx",displayName:"RouterHead_component",canonicalFilename:"s_zrbrqoaqxsy",hash:"zrbrqoaqXSY",ctxKind:"function",ctxName:"component$",captures:!1,parent:null,loc:[244,978]},s_RPDJAz33WLA:{origin:"../node_modules/@builder.io/qwik-city/index.qwik.mjs",displayName:"QwikCityProvider_component_useStyles",canonicalFilename:"s_rpdjaz33wla",hash:"RPDJAz33WLA",ctxKind:"function",ctxName:"useStyles$",captures:!1,parent:"s_TxCFOy819ag",loc:[23876,23910]},s_HU55RV7VfPc:{origin:"routes/demo/flower/index.tsx",displayName:"flower_component_useStylesScoped",canonicalFilename:"s_hu55rv7vfpc",hash:"HU55RV7VfPc",ctxKind:"function",ctxName:"useStylesScoped$",captures:!1,parent:"s_PxZ05oEiFy8",loc:[270,276]},s_A5bZC7WO00A:{origin:"../node_modules/@builder.io/qwik-city/index.qwik.mjs",displayName:"routeActionQrl_action_submit",canonicalFilename:"s_a5bzc7wo00a",hash:"A5bZC7WO00A",ctxKind:"function",ctxName:"submit",captures:!0,parent:null,loc:[41964,43598]},s_DyVc0YBIqQU:{origin:"../node_modules/@builder.io/qwik-city/index.qwik.mjs",displayName:"spa_init",canonicalFilename:"s_dyvc0ybiqqu",hash:"DyVc0YBIqQU",ctxKind:"function",ctxName:"spaInit",captures:!1,parent:null,loc:[1391,6872]},s_wOIPfiQ04l4:{origin:"../node_modules/@builder.io/qwik-city/index.qwik.mjs",displayName:"serverQrl_stuff",canonicalFilename:"s_woipfiq04l4",hash:"wOIPfiQ04l4",ctxKind:"function",ctxName:"stuff",captures:!0,parent:null,loc:[46920,48965]},s_BUbtvTyvVRE:{origin:"../node_modules/@builder.io/qwik-city/index.qwik.mjs",displayName:"QwikCityMockProvider_component_goto",canonicalFilename:"s_bubtvtyvvre",hash:"BUbtvTyvVRE",ctxKind:"function",ctxName:"goto",captures:!1,parent:"s_WmYC5H00wtI",loc:[37248,37326]},s_D04jAYuCnhM:{origin:"components/starter/counter/counter.tsx",displayName:"counter_component_div_button_onClick",canonicalFilename:"s_d04jayucnhm",hash:"D04jAYuCnhM",ctxKind:"eventHandler",ctxName:"onClick$",captures:!0,parent:"s_5Go3iiHXUB4",loc:[472,503]},s_JKHgMZ4xLZQ:{origin:"routes/layout.tsx",displayName:"layout_component_useStyles",canonicalFilename:"s_jkhgmz4xlzq",hash:"JKHgMZ4xLZQ",ctxKind:"function",ctxName:"useStyles$",captures:!1,parent:"s_VkLNXphUh5s",loc:[949,955]},s_JtGc0nS5Nuo:{origin:"routes/demo/flower/index.tsx",displayName:"flower_component_div_input_onInput",canonicalFilename:"s_jtgc0ns5nuo",hash:"JtGc0nS5Nuo",ctxKind:"eventHandler",ctxName:"onInput$",captures:!0,parent:"s_PxZ05oEiFy8",loc:[993,1059]},s_LkCVrojX09Y:{origin:"components/starter/counter/counter.tsx",displayName:"counter_component_div_button_onClick_1",canonicalFilename:"s_lkcvrojx09y",hash:"LkCVrojX09Y",ctxKind:"eventHandler",ctxName:"onClick$",captures:!0,parent:"s_5Go3iiHXUB4",loc:[648,679]},s_NYEDprtA0Lw:{origin:"components/starter/next-steps/next-steps.tsx",displayName:"next_steps_component_div_button_onClick_1",canonicalFilename:"s_nyedprta0lw",hash:"NYEDprtA0Lw",ctxKind:"eventHandler",ctxName:"onClick$",captures:!0,parent:"s_kJCtKbc9zbk",loc:[2950,2986]},s_Osdg8FnYTw4:{origin:"../node_modules/@builder.io/qwik-city/index.qwik.mjs",displayName:"Link_component_handlePrefetch",canonicalFilename:"s_osdg8fnytw4",hash:"Osdg8FnYTw4",ctxKind:"function",ctxName:"handlePrefetch",captures:!1,parent:"s_8gdLBszqbaM",loc:[38989,39320]},s_UxlJFslpf0s:{origin:"components/starter/next-steps/next-steps.tsx",displayName:"next_steps_component_useOnWindow",canonicalFilename:"s_uxljfslpf0s",hash:"UxlJFslpf0s",ctxKind:"function",ctxName:"$",captures:!0,parent:"s_kJCtKbc9zbk",loc:[1901,2009]},s_aXA3vNn55QE:{origin:"components/starter/counter/counter.tsx",displayName:"counter_component_setCount",canonicalFilename:"s_axa3vnn55qe",hash:"aXA3vNn55QE",ctxKind:"function",ctxName:"$",captures:!0,parent:"s_5Go3iiHXUB4",loc:[223,340]},s_fX0bDjeJa0E:{origin:"../node_modules/@builder.io/qwik-city/index.qwik.mjs",displayName:"QwikCityProvider_component_goto",canonicalFilename:"s_fx0bdjeja0e",hash:"fX0bDjeJa0E",ctxKind:"function",ctxName:"goto",captures:!0,parent:"s_TxCFOy819ag",loc:[25160,26479]},s_gRRz00JItKA:{origin:"components/starter/next-steps/next-steps.tsx",displayName:"next_steps_component_div_button_onClick",canonicalFilename:"s_grrz00jitka",hash:"gRRz00JItKA",ctxKind:"eventHandler",ctxName:"onClick$",captures:!0,parent:"s_kJCtKbc9zbk",loc:[2710,2742]},s_p9MSze0ojs4:{origin:"../node_modules/@builder.io/qwik-city/index.qwik.mjs",displayName:"GetForm_component_form_onSubmit",canonicalFilename:"s_p9msze0ojs4",hash:"p9MSze0ojs4",ctxKind:"function",ctxName:"_jsxS",captures:!0,parent:"s_Nk9PlpjQm9Y",loc:[51386,52083]},s_pIf0khHUxfY:{origin:"../node_modules/@builder.io/qwik-city/index.qwik.mjs",displayName:"Link_component_handleClick",canonicalFilename:"s_pif0khhuxfy",hash:"pIf0khHUxfY",ctxKind:"function",ctxName:"handleClick",captures:!0,parent:"s_8gdLBszqbaM",loc:[39747,40267]},s_zwO7CtYmrPQ:{origin:"components/starter/hero/hero.tsx",displayName:"hero_component_div_div_button_onClick",canonicalFilename:"s_zwo7ctymrpq",hash:"zwO7CtYmrPQ",ctxKind:"eventHandler",ctxName:"onClick$",captures:!1,parent:"s_fle1EaVOup8",loc:[582,2217]}},mapping:{s_02wMImzEAbk:"q-CQ8Q0PQk.js",s_LQPhZ0qOjrk:"q-4nj7sJgW.js",s_3sccYCDd1Z0:"q-CbUiM095.js",s_5Go3iiHXUB4:"q-cUpm2bqP.js",s_7gzriUtQs98:"q-DiI_TqXB.js",s_8gdLBszqbaM:"q-lLwaWssg.js",s_J4V2qsF7Yxo:"q-DRaAPhkF.js",s_Nk9PlpjQm9Y:"q-DWEi2z0s.js",s_PxZ05oEiFy8:"q-4nj7sJgW.js",s_TxCFOy819ag:"q-CQ8Q0PQk.js",s_VkLNXphUh5s:"q-k6V3mfgu.js",s_WmYC5H00wtI:"q-DpoW9F5E.js",s_e0ssiDXoeAM:"q-D0TuXTFA.js",s_fle1EaVOup8:"q-a_rW6WaU.js",s_foRSjkQluCc:"q-BDyvhXCt.js",s_kJCtKbc9zbk:"q-DdyXC1Qn.js",s_mBt9fIl89mc:"q-Cub0eN47.js",s_u0bwM0i5dA8:"q-BuaEYuJL.js",s_xYL1qOwPyDI:"q-S0Uazj20.js",s_zrbrqoaqXSY:"q-C_MSYrBR.js",s_RPDJAz33WLA:"q-CQ8Q0PQk.js",s_HU55RV7VfPc:"q-4nj7sJgW.js",s_A5bZC7WO00A:"q-BvfioDAX.js",s_DyVc0YBIqQU:"q-fJkQnue_.js",s_wOIPfiQ04l4:"q-DT1CTYgK.js",s_BUbtvTyvVRE:"q-DpoW9F5E.js",s_D04jAYuCnhM:"q-cUpm2bqP.js",s_JKHgMZ4xLZQ:"q-k6V3mfgu.js",s_JtGc0nS5Nuo:"q-4nj7sJgW.js",s_LkCVrojX09Y:"q-cUpm2bqP.js",s_NYEDprtA0Lw:"q-DdyXC1Qn.js",s_Osdg8FnYTw4:"q-lLwaWssg.js",s_UxlJFslpf0s:"q-DdyXC1Qn.js",s_aXA3vNn55QE:"q-cUpm2bqP.js",s_fX0bDjeJa0E:"q-CQ8Q0PQk.js",s_gRRz00JItKA:"q-DdyXC1Qn.js",s_p9MSze0ojs4:"q-DWEi2z0s.js",s_pIf0khHUxfY:"q-lLwaWssg.js",s_zwO7CtYmrPQ:"q-DzP1xvWc.js"},bundles:{"q-4nj7sJgW.js":{size:2865,imports:["q-C1tQtgUd.js","q-riWhM7DD.js"],origins:["src/entry_flower.js","src/routes/demo/flower/flower.css?inline","src/s_hu55rv7vfpc.js","src/s_jtgc0ns5nuo.js","src/s_lqphz0qojrk.js","src/s_pxz05oeify8.js"],symbols:["s_HU55RV7VfPc","s_JtGc0nS5Nuo","s_LQPhZ0qOjrk","s_PxZ05oEiFy8"]},"q-a_rW6WaU.js":{size:1369,imports:["q-C1tQtgUd.js"],dynamicImports:["q-DzP1xvWc.js"],origins:["src/components/starter/hero/hero.module.css","src/entry_hero.js","src/media/thunder.png?jsx","src/s_fle1eavoup8.js"],symbols:["s_fle1EaVOup8"]},"q-BDyvhXCt.js":{size:261,imports:["q-C1tQtgUd.js"],origins:["src/components/starter/infobox/infobox.module.css","src/entry_infobox.js","src/s_forsjkqlucc.js"],symbols:["s_foRSjkQluCc"]},"q-BFLBp0Ev.js":{size:437,imports:["q-C1tQtgUd.js"],dynamicImports:["q-S0Uazj20.js"],origins:["src/routes/index.tsx"]},"q-Bq36Wx9q.js":{size:2539,origins:["node_modules/@builder.io/qwik-city/service-worker.mjs","src/routes/service-worker.ts"]},"q-BtT7fSuj.js":{size:534,imports:["q-C1tQtgUd.js","q-riWhM7DD.js"],dynamicImports:["q-k6V3mfgu.js"],origins:["src/routes/layout.tsx"]},"q-BuaEYuJL.js":{size:550,imports:["q-BtT7fSuj.js","q-C1tQtgUd.js","q-riWhM7DD.js"],origins:["src/components/starter/footer/footer.module.css","src/entry_footer.js","src/s_u0bwm0i5da8.js"],symbols:["s_u0bwM0i5dA8"]},"q-BvfioDAX.js":{size:751,imports:["q-C1tQtgUd.js"],origins:["src/entry_routeActionQrl.js","src/s_a5bzc7wo00a.js"],symbols:["s_A5bZC7WO00A"]},"q-C1tQtgUd.js":{size:52198,origins:["node_modules/@builder.io/qwik/core.min.mjs"]},"q-C_MSYrBR.js":{size:765,imports:["q-C1tQtgUd.js","q-riWhM7DD.js"],origins:["src/entry_RouterHead.js","src/s_zrbrqoaqxsy.js"],symbols:["s_zrbrqoaqXSY"]},"q-CbUiM095.js":{size:673,imports:["q-C1tQtgUd.js","q-riWhM7DD.js"],dynamicImports:["q-C_MSYrBR.js"],origins:["src/components/router-head/router-head.tsx","src/entry_root.js","src/s_3sccycdd1z0.js"],symbols:["s_3sccYCDd1Z0"]},"q-CLBUwhSV.js":{size:543,imports:["q-C1tQtgUd.js","q-riWhM7DD.js"],dynamicImports:["q-DRaAPhkF.js"],origins:["src/routes/demo/todolist/index.tsx"]},"q-CQ8Q0PQk.js":{size:5957,imports:["q-C1tQtgUd.js","q-riWhM7DD.js"],dynamicImports:["q-BFLBp0Ev.js","q-BtT7fSuj.js","q-CLBUwhSV.js","q-CYcHZWhS.js","q-Di9nwrXR.js"],origins:["@qwik-city-plan","src/entry_QwikCityProvider.js","src/s_02wmimzeabk.js","src/s_fx0bdjeja0e.js","src/s_rpdjaz33wla.js","src/s_txcfoy819ag.js"],symbols:["s_02wMImzEAbk","s_fX0bDjeJa0E","s_RPDJAz33WLA","s_TxCFOy819ag"]},"q-Cub0eN47.js":{size:3824,imports:["q-C1tQtgUd.js"],origins:["src/components/starter/header/header.module.css","src/components/starter/icons/qwik.tsx","src/entry_header.js","src/s_mbt9fil89mc.js"],symbols:["s_mBt9fIl89mc"]},"q-cUpm2bqP.js":{size:1322,imports:["q-C1tQtgUd.js"],dynamicImports:["q-DiI_TqXB.js"],origins:["src/components/starter/counter/counter.module.css","src/components/starter/gauge/index.tsx","src/entry_counter.js","src/s_5go3iihxub4.js","src/s_axa3vnn55qe.js","src/s_d04jayucnhm.js","src/s_lkcvrojx09y.js"],symbols:["s_5Go3iiHXUB4","s_aXA3vNn55QE","s_D04jAYuCnhM","s_LkCVrojX09Y"]},"q-CYcHZWhS.js":{size:373,imports:["q-C1tQtgUd.js"],dynamicImports:["q-4nj7sJgW.js"],origins:["src/routes/demo/flower/index.tsx"]},"q-D0TuXTFA.js":{size:462,imports:["q-C1tQtgUd.js","q-riWhM7DD.js"],origins:["src/entry_RouterOutlet.js","src/s_e0ssidxoeam.js"],symbols:["s_e0ssiDXoeAM"]},"q-DaHW60yx.js":{size:339,imports:["q-C1tQtgUd.js"],dynamicImports:["q-CbUiM095.js"],origins:["src/global.css","src/root.tsx"]},"q-DdyXC1Qn.js":{size:1683,imports:["q-C1tQtgUd.js","q-nkLEI_37.js"],origins:["src/components/starter/next-steps/next-steps.module.css","src/entry_next_steps.js","src/s_grrz00jitka.js","src/s_kjctkbc9zbk.js","src/s_nyedprta0lw.js","src/s_uxljfslpf0s.js"],symbols:["s_gRRz00JItKA","s_kJCtKbc9zbk","s_NYEDprtA0Lw","s_UxlJFslpf0s"]},"q-Di9nwrXR.js":{size:322,imports:["q-C1tQtgUd.js"],dynamicImports:["q-Bq36Wx9q.js"],origins:["@qwik-city-entries"]},"q-DiI_TqXB.js":{size:955,imports:["q-C1tQtgUd.js"],origins:["src/components/starter/gauge/gauge.module.css","src/entry_gauge.js","src/s_7gzriutqs98.js"],symbols:["s_7gzriUtQs98"]},"q-DpoW9F5E.js":{size:996,imports:["q-C1tQtgUd.js","q-riWhM7DD.js"],origins:["src/entry_QwikCityMockProvider.js","src/s_bubtvtyvvre.js","src/s_wmyc5h00wti.js"],symbols:["s_BUbtvTyvVRE","s_WmYC5H00wtI"]},"q-DRaAPhkF.js":{size:1202,imports:["q-C1tQtgUd.js","q-CLBUwhSV.js","q-riWhM7DD.js"],origins:["src/entry_todolist.js","src/routes/demo/todolist/todolist.module.css","src/s_j4v2qsf7yxo.js"],symbols:["s_J4V2qsF7Yxo"]},"q-DT1CTYgK.js":{size:895,imports:["q-C1tQtgUd.js","q-riWhM7DD.js"],origins:["src/entry_serverQrl.js","src/s_woipfiq04l4.js"],symbols:["s_wOIPfiQ04l4"]},"q-DWEi2z0s.js":{size:1217,imports:["q-C1tQtgUd.js","q-riWhM7DD.js"],origins:["src/entry_GetForm.js","src/s_nk9plpjqm9y.js","src/s_p9msze0ojs4.js"],symbols:["s_Nk9PlpjQm9Y","s_p9MSze0ojs4"]},"q-DzP1xvWc.js":{size:695,origins:["src/s_zwo7ctymrpq.js"],symbols:["s_zwO7CtYmrPQ"]},"q-fJkQnue_.js":{size:2286,origins:["src/entry_spaInit.js","src/s_dyvc0ybiqqu.js"],symbols:["s_DyVc0YBIqQU"]},"q-k6V3mfgu.js":{size:5426,imports:["q-C1tQtgUd.js"],dynamicImports:["q-BuaEYuJL.js","q-Cub0eN47.js"],origins:["src/components/starter/footer/footer.tsx","src/components/starter/header/header.tsx","src/entry_layout.js","src/routes/styles.css?inline","src/s_jkhgmz4xlzq.js","src/s_vklnxphuh5s.js"],symbols:["s_JKHgMZ4xLZQ","s_VkLNXphUh5s"]},"q-lLwaWssg.js":{size:1786,imports:["q-C1tQtgUd.js","q-riWhM7DD.js"],origins:["src/entry_Link.js","src/s_8gdlbszqbam.js","src/s_osdg8fnytw4.js","src/s_pif0khhuxfy.js"],symbols:["s_8gdLBszqbaM","s_Osdg8FnYTw4","s_pIf0khHUxfY"]},"q-nkLEI_37.js":{size:1834,imports:["q-C1tQtgUd.js"],dynamicImports:["q-DdyXC1Qn.js"],origins:["src/components/starter/next-steps/next-steps.tsx"]},"q-riWhM7DD.js":{size:10034,imports:["q-C1tQtgUd.js"],dynamicImports:["q-BvfioDAX.js","q-CQ8Q0PQk.js","q-D0TuXTFA.js","q-DWEi2z0s.js","q-fJkQnue_.js"],origins:["@qwik-city-sw-register","node_modules/@builder.io/qwik-city/index.qwik.mjs"]},"q-S0Uazj20.js":{size:2935,imports:["q-C1tQtgUd.js","q-nkLEI_37.js"],dynamicImports:["q-a_rW6WaU.js","q-BDyvhXCt.js","q-cUpm2bqP.js"],origins:["src/components/starter/counter/counter.tsx","src/components/starter/hero/hero.tsx","src/components/starter/infobox/infobox.tsx","src/entry_routes.js","src/s_xyl1qowpydi.js"],symbols:["s_xYL1qOwPyDI"]}},injections:[{tag:"style",location:"head",attributes:{"data-src":"/build/q-CceB0glr.css",dangerouslySetInnerHTML:`._counter-wrapper_43sys_1{margin-top:50px;display:flex;align-items:center;justify-content:center;gap:10px}@media screen and (min-width: 768px){._counter-wrapper_43sys_1{gap:30px}}._anchor_1g8hj_1{color:#fff!important;display:block;font-size:.8rem;text-align:center;text-decoration:none;line-height:1.5}._anchor_1g8hj_1 span:not(._spacer_1g8hj_10){display:block}._spacer_1g8hj_10{display:none;padding:0 15px}@media screen and (min-width: 768px){._anchor_1g8hj_1 span{display:inline!important}}._wrapper_1v6hy_1{position:relative}._gauge_1v6hy_5{width:160px}._value_1v6hy_9{position:absolute;top:50%;left:50%;color:#fff;font-size:3rem;transform:translate(-50%,-50%);width:200px;text-align:center}@media screen and (min-width: 768px){._gauge_1v6hy_5{width:400px}._value_1v6hy_9{font-size:7rem}}._wrapper_tofv3_1{display:flex;align-items:center;justify-content:space-between}._logo_tofv3_7{display:inline-block}._logo_tofv3_7 a{display:block}._header_tofv3_14 ul{margin:0;padding:0;list-style:none;display:flex;gap:30px}._header_tofv3_14 li{display:none;margin:0;padding:0;font-size:.7rem}._header_tofv3_14 li a{color:#fff;display:inline-block;padding:0;text-decoration:none}._header_tofv3_14 li a:hover{color:var(--qwik-light-blue)}@media (min-width: 450px){._header_tofv3_14 li{display:inline-block}}._hero_resu5_1{display:flex;vertical-align:middle;flex-direction:column;flex-wrap:nowrap;align-items:center;height:450px;justify-content:center;gap:40px}._hero-image_resu5_12{width:100%;position:absolute;height:auto;object-fit:cover;z-index:-1;opacity:.2;pointer-events:none}._hero_resu5_1 p{color:#fff;margin:0;font-size:1rem}._button-group_resu5_28{display:flex;flex-direction:row;gap:24px}@media screen and (min-width: 768px){._hero_resu5_1{gap:60px;height:500px}._hero_resu5_1 p{font-size:1.3rem}}._infobox_oa4r7_1{color:#fff;font-size:.8rem;line-height:2;margin:0 0 40px}._infobox_oa4r7_1 h3{font-size:1rem;font-weight:400;margin:0 0 15px;padding:0}._infobox_oa4r7_1 li{line-height:2.5}@media screen and (min-width: 600px){._infobox_oa4r7_1{margin:0}}._gettingstarted_32zqp_1{display:flex;color:#fff;flex-direction:column;justify-content:center;align-items:center;height:280px;line-height:1.5;gap:10px;max-width:600px;margin:0 auto}._gettingstarted_32zqp_1 ._intro_32zqp_14{font-size:1rem;width:100%;word-break:break-word}._gettingstarted_32zqp_1 ._hint_32zqp_19{font-size:.8rem}._gettingstarted_32zqp_1 ._hint_32zqp_19 a{color:var(--qwik-dark-purple)}@media screen and (min-width: 768px){._gettingstarted_32zqp_1{height:180px}._gettingstarted_32zqp_1 ._intro_32zqp_14{font-size:1.2rem}._gettingstarted_32zqp_1 ._hint_32zqp_19{font-size:1rem}}._list_1ofyy_1{display:flex;flex-direction:column;gap:20px;color:#fff}._list_1ofyy_1,._empty_1ofyy_9{min-height:250px}._list_1ofyy_1 li{list-style:none}._empty_1ofyy_9{color:#fff;display:block}._input_1ofyy_22{background:#fff;color:var(--qwik-light-blue);border:none;border-radius:8px;padding:15px 20px;margin-right:10px;font-size:.8rem}._hint_1ofyy_32{font-size:.8rem;color:#fff;margin-top:30px}@media screen and (min-width: 768px){._input_1ofyy_22{padding:23px 35px;margin-right:20px;font-size:1rem}}:root{--qwik-dark-blue: #006ce9;--qwik-light-blue: #18b6f6;--qwik-light-purple: #ac7ff4;--qwik-dark-purple: #713fc2;--qwik-dirty-black: #1d2033;--qwik-dark-background: #151934;--qwik-dark-text: #ffffff}html{line-height:1;-webkit-text-size-adjust:100%;-moz-tab-size:4;-o-tab-size:4;tab-size:4;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol,"Noto Color Emoji"}body{padding:0;margin:0;line-height:inherit}
`}}],version:"1",options:{target:"client",buildMode:"production",entryStrategy:{type:"smart"}},platform:{qwik:"1.4.5",vite:"",rollup:"4.12.0",env:"node",os:"win32",node:"20.11.1"}},Oe=()=>{const e=ue(),n=de();return g(z,{children:[y("title",null,null,e.title,1,null),y("link",null,{href:pe(t=>t.url.href,[n],"p0.url.href"),rel:"canonical"},null,3,null),y("meta",null,{content:"width=device-width, initial-scale=1.0",name:"viewport"},null,3,null),y("link",null,{href:"/favicon.svg",rel:"icon",type:"image/svg+xml"},null,3,null),e.meta.map(t=>w("meta",{...t},null,0,t.key)),e.links.map(t=>w("link",{...t},null,0,t.key)),e.styles.map(t=>w("style",{...t.props,dangerouslySetInnerHTML:J(t,"style")},null,0,t.key)),e.scripts.map(t=>w("script",{...t.props,dangerouslySetInnerHTML:J(t,"script")},null,0,t.key))]},1,"OA_0")},Be=H(V(Oe,"s_zrbrqoaqXSY")),Ke=()=>g(ye,{children:[y("head",null,null,[y("meta",null,{charSet:"utf-8"},null,3,null),y("link",null,{href:"/manifest.json",rel:"manifest"},null,3,null),g(Be,null,3,"35_0"),g(fe,null,3,"35_1")],1,null),y("body",null,{lang:"en"},g(_e,null,3,"35_2"),1,null)]},1,"35_3"),$e=H(V(Ke,"s_3sccYCDd1Z0"));function Ve(e){return Ue(g($e,null,3,"pY_0"),{manifest:Me,...e,containerAttributes:{lang:"en-us",...e.containerAttributes}})}export{Me as m,Ve as r,He as s};
